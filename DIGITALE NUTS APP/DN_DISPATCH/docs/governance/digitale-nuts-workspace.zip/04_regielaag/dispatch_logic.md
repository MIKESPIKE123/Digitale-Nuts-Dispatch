# Dispatch_Logic

Versie: 0.1  
Datum:  

## Context

## Beslissing

## Impact

## Volgende stappen
